import logo from "./logo.svg";
import "./App.css";
import { Col, Nav, Navbar, NavDropdown, Row, Button, Carousel, Card, ListGroup, InputGroup, FormControl } from "react-bootstrap";
import { BsFillTelephoneFill, BsSearch } from "react-icons/bs";
import { MdMailOutline } from "react-icons/md";
import Slider from "react-slick";
import LogoInstansi from './logo-lampung-timur.png'

function App() {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3
  };

  return (
    <div className="bg-1">
      <Row className="bg-2">
        <Col xs={6}>
          <div className="container-logo-header">
            <img width={300} height={75}
              alt="images"
              src={LogoInstansi}></img>
          </div>

        </Col>
        <Col xs={6}>
          <div className="text-right container-icon-navbar">
            <div className="ct-container">
              <BsFillTelephoneFill className="size-icon-tel" />
              <div className="text-container-navbar">
                <h3 className="size-text">Hubungi Kami</h3>
                <p className="size-tel">+6289536213823</p>
              </div>
            </div>

            <div className="ct-container">
              <MdMailOutline className="size-icon-email" />
              <div className="text-container-navbar">
                <h3 className="size-text">Email</h3>
                <p className="size-tel">example@gmail.com</p>
              </div>
            </div>

          </div>
        </Col>
      </Row>

      <Row>
        <Col xs={12}>
          <div className="container-search-input">
            {/* <input type="text" className="form-input-search-navbar" /> */}
            <InputGroup className="mb-0 input-search-navbar">
              <FormControl
                className="input-search-navbar"
                placeholder="Cari apapun disini ..."
                aria-label="Recipient's username"
                aria-describedby="basic-addon2"
              />
              <Button variant=" bg-btn-search-navbar" id="button-addon2">
                <BsSearch />
              </Button>
            </InputGroup>
          </div>
        </Col>
      </Row>
      {/* </div> */}
      <Row>
        <Col xs={12}>
          <div className="bg-primary">

          <div className="container-navbar-text justify-content-end">
              <Navbar bg="light" expand="lg">
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse className="justify-content-center" id="basic-navbar-nav">
                  <Nav className="margin-navbar-text">
                    <Nav.Link className="font-bold uppercase roboto css-text-navbar" href="#home">Home</Nav.Link>
                    <Nav.Link className="font-bold uppercase roboto css-text-navbar" href="#home">Pages</Nav.Link>
                    <Nav.Link className="font-bold uppercase roboto css-text-navbar" href="#home">Portfolio</Nav.Link>
                    <Nav.Link className="font-bold uppercase roboto css-text-navbar" href="#home">Mega Menu</Nav.Link>
                    <NavDropdown className="font-bold uppercase roboto css-text-navbar" title="Dropdown" id="basic-nav-dropdown">
                      <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
                      <NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
                      <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
                      <NavDropdown.Divider />
                      <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
                    </NavDropdown>
                    <NavDropdown className="font-bold uppercase roboto css-text-navbar" title="Dropdown" id="basic-nav-dropdown">
                      <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
                      <NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
                      <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
                      <NavDropdown.Divider />
                      <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
                    </NavDropdown>
                    <Nav.Link className="font-bold uppercase roboto css-text-navbar" href="#home">Profile</Nav.Link>
                    <Nav.Link className="font-bold uppercase roboto css-text-navbar" href="#home">Hubungi Kami</Nav.Link>
                  </Nav>
                </Navbar.Collapse>
              </Navbar>
            </div>
		   
          </div>
          <Carousel>
            <Carousel.Item>
              <img
                className="d-block w-100"
                src="https://www.dinastph.lampungprov.go.id/uploads/whatsapp_image_2020-05-18_at_3.09.07_pm_(1).jpg"
                alt="First slide"
                style={{ height: "550px" }}
              />
            </Carousel.Item>
            <Carousel.Item>
              <img
                className="d-block w-100"
                src="https://www.lampost.co/upload/b38cd2ce6d03dc9a42b2488c37145a8e.jpg"
                alt="Second slide"
                style={{ height: "550px" }}
              />
            </Carousel.Item>
            <Carousel.Item>
              <img
                className="d-block w-100"
                src="https://dinastph.lampungprov.go.id/uploads/298whatsapp_image_2019-12-21_at_16.13.47.jpeg"
                alt="Third slide"
                style={{ height: "550px" }}
              />
            </Carousel.Item>
          </Carousel>
        </Col>
      </Row>

      {" "}
      <div className="bg-berita">
            <Row>
              <Col xs={4}>
                <Card>
                  <Card.Img variant="top" src="https://pertanian.go.id//home/upload/news/2475_sosmed.jpg" />
                  <Card.Body>
                    <p>05 Maret 2022, 40x dibaca</p>
                    <Card.Title>Gosip</Card.Title>
                    <Card.Text>
                      Some quick example text to build on the card title and make up the bulk of
                      the card's content.
                    </Card.Text>
                    <a href="">Read more</a>
                  </Card.Body>
                </Card>
              </Col>
              <Col xs={4}>
                <Card>                
                  <Card.Img variant="top" src="https://pertanian.go.id//home/upload/news/2475_sosmed.jpg" />
                  <Card.Body>
                    <p>06 Maret 2022, 3x dibaca</p>
                    <Card.Title>Card Title</Card.Title>
                    <Card.Text>
                      Some quick example text to build on the card title and make up the bulk of
                      the card's content.
                    </Card.Text>
                    <a href="">Read more</a>
                  </Card.Body>
                </Card>
              </Col>
              <Col xs={4}>
                <ListGroup>
                  <ListGroup.Item>
                    <h4>Ajeng juara 1 lomba gibah</h4><p>1 januri 2022</p></ListGroup.Item>
                  <ListGroup.Item>Fajar pacar kak irpan</ListGroup.Item>
                  <ListGroup.Item>Rindi si jomblo terlama</ListGroup.Item>
                </ListGroup>
              </Col>
            </Row>
          </div>
      <div>
        <div>
          <div className="bg-gallery">
            <h2 className="title-h2-main font-bold roboto"> Gallery </h2>
            <Slider {...settings}>
              <div>
                <img className="width-full" src="https://dinastph.lampungprov.go.id/uploads/panen-sayur-di-pekarangan-pangan-lestari-bersama-mentan-di-lampung-tengah.jpg"></img>
              </div>
              <div>
                <img className="width-full" height={200} src="https://www.bumi1.com/wp-content/uploads/2020/05/IMG_20200520_100028-scaled.jpg"></img>
              </div>
              <div>
                <img className="width-full" height={200} src="https://www.suarawajarfm.com/wp-content/uploads/2018/10/ir-kusnardi-lpg1.jpeg"></img>
              </div>
              <div>
                <img className="width-full" height={200} src="https://www.suarawajarfm.com/wp-content/uploads/2018/10/ir-kusnardi-lpg1.jpeg"></img>
              </div>
              <div>
                <img className="width-full" height={200} src="https://www.suarawajarfm.com/wp-content/uploads/2018/10/ir-kusnardi-lpg1.jpeg"></img>
              </div>
            </Slider>
          </div>
        </div>

        <Row className="bg-bawah">
          <Col xs={8}>
			  <div className="container-logo-footer">
			  		<h1>Dinas Ketahanan Pangan</h1>
			  </div>
          </Col>
		  <Col xs={4} className="text-right">
			  <img width={90} src="https://logodownload.org/wp-content/uploads/2014/09/twitter-logo-4.png" />
          </Col>
          <Col className="container-text-footer" xs={12}>
			<Row>
				<Col xs={3} className="footer-contain">
					<h3 className="footer-contain-text">TENTANG</h3>
					<p className="footer-keterangan-dinas">Dinas Ketahanan Pangan merupakan unsur penunjang mempunyai tugas pokok mendukung dan membantu Walikota melaksanakan urusan pemerintahan konkuren bidang pangan yang menjadi kewenangan Pemerintah Daerah</p>
				</Col>
				<Col xs={3} className="footer-contain footer-margin-left">
					<h3 className="footer-contain-text">TENTANG</h3>
					<ul className="footer-list-margin">
						<li><a className="footer-href-text" href="">Profile</a></li>
						<li><a className="footer-href-text" href="">Kepala Dinas</a></li>
						<li><a className="footer-href-text" href="">Dokumen</a></li>
						<li><a className="footer-href-text" href="">Wakil Kepala Dinas</a></li>
					</ul>
				</Col>
				<Col xs={3} className="footer-contain">
					<h3 className="footer-contain-text">TENTANG</h3>
					<ul className="footer-list-margin">
						<li><a className="footer-href-text" href="">Profile</a></li>
						<li><a className="footer-href-text" href="">Kepala Dinas</a></li>
						<li><a className="footer-href-text" href="">Dokumen</a></li>
						<li><a className="footer-href-text" href="">Wakil Kepala Dinas</a></li>
					</ul>
				</Col>
				<Col xs={3} className="footer-contain">
					<h3 className="footer-contain-text">LOKASI</h3>
					<iframe className="maps" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3972.3831079823235!2d105.23076191430232!3d-5.358373355129624!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e40c54fa0db33eb%3A0xe69b7788ca97353a!2sLampung%20State%20Polytechnic!5e0!3m2!1sen!2sid!4v1647234289739!5m2!1sen!2sid" width={600} height={450} style={{ border: 0 }} allowFullScreen loading="lazy" />
				</Col>
			</Row>
          </Col>
          <Col className="" xs={12}>
		  	<Row>
				<Col xs={6} className="footer-contain text-cc">2021 Copyright Dinas Pendidikan dan Ketahanan Pangan</Col>
				<Col xs={6} className="footer-contain text-right text-cc">Kabupaten Lampung Timur</Col>
			</Row>
		  </Col>
        </Row>
      </div>
    </div>
  );
}

export default App;
